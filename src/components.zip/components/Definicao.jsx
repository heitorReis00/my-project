import TittleTwo from "../tags/TittleTwo"
import TextDef from "./textDef"
import { useState } from "react"
import Buttons from "../tags/Buttons"

export default function Definicao() {

const [mais, setMais] = useState(false)

function HandleClickMais() {
  setMais(!mais)
}

    return (
        <section>
            <TittleTwo>O que é Inclusão Social?</TittleTwo>
          <p>
            Inclusão social é o processo de garantir que todas as pessoas,
            independentemente de suas características, condições físicas,
            sociais ou culturais, tenham acesso pleno e igualitário a
            oportunidades, direitos e espaços na sociedade.
          </p>
          <img src="/src/assets/Reuniao.jpg" alt="" className="object-cover my-5 aspect-[3/4]"  />
          {mais && <TextDef/>}
          <Buttons><button onClick={HandleClickMais}>Ler mais...</button></Buttons>

             
        </section>
    )
}