export default function Spacing() {
    return (
        <div className="bg-yellow-300 h-[1px]  my-20"></div>
    )
}